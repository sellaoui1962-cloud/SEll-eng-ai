/// **内置技能**（S1/S2/S3 的 Skill 层，2026-10-24 接线）。
///
/// ## 这是什么
///
/// 重复性流程沉淀为**提示型技能**：名称 + 触发条件 + 工作流，平时只在
/// 系统提示里占一行目录（渐进披露），模型按任务用 `activate_skills`
/// 按需加载全文 —— 这是教材第 9 章的标准形态，也与 Claude Code 的
/// Skill 机制同构。
///
/// ## 为什么只有这三条
///
/// 只沉淀**跨任务复用、且模型经常自发做错**的流程。每条都对应
/// 对照表里的一个真实欠账：
///
/// · `verify-loop` ↔ H3/K2（自验证循环）：架构级管线没有，但"改完必验、
///   失败进修复循环"的**流程纪律**可以用技能承载 —— 模型激活后每一轮
///   都看得见全文，比散在 system prompt 里的一句话强得多；
/// · `root-cause-first` ↔ K1（代码理解先于修改）；
/// · `small-steps` ↔ K3（小步修改）。
///
/// ## 刻意不做的
///
/// · **不设 `forceActivate`**：三条都是"按需激活"——强塞全文等于回到
///   "教练式 system prompt"的老路（`system_prompt.dart` 文件头记过教训）；
/// · 不做代码型技能 / 目录模式（`skillDirectoryPaths`）：等有真实的
///   用户侧技能需求再说，现在只有内置三条。
library;

import 'package:dart_agent_core/dart_agent_core.dart';

import '../agent/v4_extensions.dart';
import '../contract/contract.dart';

/// 内置技能的**唯一清单**（组装层读这里；测试断言也钉这里）。
List<Skill> builtinSkills() => [
      _BuiltinSkill(
        name: 'verify-loop',
        description: '构建-验证-修复循环：改完代码/配置后自动验证，失败进修复循环',
        systemPrompt: '''
## 技能：verify-loop（构建-验证-修复循环）

**何时用**：你修改了代码、配置或补丁之后；用户要求"跑通/修好/验证"。

**工作流（每轮都按这个走）**：
1. **验证**：优先用项目里已有的验证手段（构建命令、测试、`run_shell_command`）；
   没有现成手段就用最轻的核对（读回改过的文件、跑一次最小复现）。
2. **判定**：验证输出里找**具体失败证据**（报错原文、失败的测试名），
   不要凭感觉判定"应该好了"。
3. **修复**：定位到根因再改 —— 一次只改一个可疑点，改完**立刻回到第 1 步**。
4. **收尾**：连续 3 次修复仍失败 ⇒ 停下，向用户如实报告：
   已试过什么、卡在哪个证据上、建议下一步。**不许宣称"修好了"而没有验证证据。**
''',
      ),
      _BuiltinSkill(
        name: 'root-cause-first',
        description: '先诊断再动手：bug 修复类任务先读代码定位根因，再改',
        systemPrompt: '''
## 技能：root-cause-first（先诊断再动手）

**何时用**：修 bug、修报错、"不对劲"类任务。

**工作流**：
1. **复现/观察**：先拿到完整证据（报错原文、相关日志、复现步骤）；
   拿不到就先问用户或用工具取。
2. **定位**：用 grep_files/read_file 读相关代码，找到**触发路径** ——
   从报错点往上追到"哪一行做出了错误决定"。
3. **假设**：用一句话写下"我认为根因是 X，证据是 Y"。
4. **改**：只改根因处；顺手修别的症状前先说明理由。
5. **验证**：确认原证据消失（接 verify-loop 技能）。

**红线**：没有证据支持的"修复"不许动手 —— 那是猜，猜错会把问题改没影。
''',
      ),
      _BuiltinSkill(
        name: 'small-steps',
        description: '小步修改：多文件/大改动拆成一次一件，改完即验',
        systemPrompt: '''
## 技能：small-steps（小步修改）

**何时用**：改动跨多个文件、或单处改动超过 ~50 行、或拿不准影响面。

**工作流**：
1. **拆步**：把改动列成 `write_todos`，每步 = 一个文件/一个关注点。
2. **一步一件**：每步用 `edit`/`apply_patch`（不整文件重写），
   保持原有代码风格与结构。
3. **步内即验**：每步完成立刻核对（读回 / 构建该文件），
   错了当场修 —— 不攒到最后一起验。
4. **顺序**：先改被依赖的，再改依赖方；每步之后影响面应当是收敛的。

**红线**：禁止为了"快"把三个文件的改动揉进一次 write_file ——
出了问题你分不清是哪一步引入的。
''',
      ),
    ];

class _BuiltinSkill extends Skill {
  _BuiltinSkill({
    required super.name,
    required super.description,
    required super.systemPrompt,
  });
}

/// **导出内置技能清单**（V0.4 F1，2026-11-02；契约见 `docs/INTERFACE.md` §N16.1）。
///
/// ## 为什么要有这个函数
///
/// 前端 Skills 页需要列出**内置**技能才能做启停开关；此前内置三条只活在
/// 系统提示的"技能目录"一行里，App 侧完全看不见 ⇒ 页面只能列出用户技能，
/// 用户会以为"内置技能没了"。
///
/// ## 为什么从 [builtinSkills] 映射而不是再抄一份
///
/// 抄一份就有两个真相：改了正文忘了改清单 ⇒ 页面显示的描述和模型实际看到的
/// 不一致，而且**测试抓不到**（两边各自绿）。这里直接映射，源头永远一个。
///
/// `source` 固定 `builtin`；`enabled` 给 `true` 只表示**出厂默认值** ——
/// 用户改过的启停状态在宿主（见 `ContractSkills` 的说明），会覆盖这个默认。
List<SkillEntry> builtinSkillEntries() => [
      for (final s in builtinSkills())
        SkillEntry(
          name: s.name,
          description: s.description,
          body: s.systemPrompt,
          source: ContractSkills.sourceBuiltin,
        ),
    ];
